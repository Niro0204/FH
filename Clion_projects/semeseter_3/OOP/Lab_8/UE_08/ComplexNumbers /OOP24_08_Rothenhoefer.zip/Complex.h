//
// Created by nico on 13.12.24.
//
#include <iostream>

#ifndef COMPLEX_H
#define COMPLEX_H



class Complex {
public:
    int a, b;
    Complex();
    ~Complex();

    void input(std::string str) {


};



#endif //COMPLEX_H
